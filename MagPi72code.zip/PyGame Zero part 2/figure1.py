import pgzrun

# Your program code will go here

pgzrun.go()
